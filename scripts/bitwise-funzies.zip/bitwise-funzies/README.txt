Assignments 1-4 corresponds to files bitwise-funzies_{1,2,3-4}.* (assingments 3-4 are combined in one files)
Each assignment holds *.c, *.out, *.txt, where *.c is compiled as *.out and its output is saved to *.txt

Explanation for assignment 2
sizeof(int) if 4. This means that data type int is expressed with 4 bytes = 32 bits. This datatype allows us to express numbers from -2147483648 to 2147483647, according to the INT_MIN and INT_MAX macro in limits.h


