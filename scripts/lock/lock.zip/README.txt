t2-lock-var.c... actual code of shared counters
t2-lock-var.out... compiled
lock.sh... runs t2-lock-var.out multiple times, with NUM_THREADS and THRESHOLD varying.
result.txt... some output (result of time command) of lock.sh is redirected to this file.
result.csv... formatted result.txt to a csv file
result.xlsx... drew graph out of result.csv

lock.pdf... submitted report 
lock.md... source file of lock.pdf
images/... graphs